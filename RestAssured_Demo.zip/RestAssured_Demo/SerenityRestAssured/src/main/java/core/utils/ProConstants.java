package core.utils;

public interface ProConstants {
    String KEY = "Key";
    String VALUE = "Value";
    String JSON_PATH = "Jsonpath";
    String COMPARE_TYPE = "Compare Type";
}
